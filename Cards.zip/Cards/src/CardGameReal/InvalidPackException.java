package CardGameReal;

public class InvalidPackException extends Exception{
    public InvalidPackException() {
        super();
    }

    public InvalidPackException(String message) {
        super(message);
    }
    
}

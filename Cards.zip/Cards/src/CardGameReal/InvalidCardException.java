package CardGameReal;

public class InvalidCardException extends Exception {
    
    public InvalidCardException() {
        super();
    }

    public InvalidCardException(String message) {
        super(message);
    }
}

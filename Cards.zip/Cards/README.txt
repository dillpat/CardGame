===Card Game Simulation===

==Contibutors== 
052039 and 008940

Running the main application

cd CardGame

java -jar cards.jar

====================
How to run the JUnit Test

cd Cards/cardsTest/cardsTest/src

java -cp ;lib\* org.junit.runner.JUnitCore AllTests

javac -cp ;lib\* AllTests.java

==Description==

This is a multi-threaded card playing simualtion.

The user inputs the number of players n to the console, these players are number from 1 to n.
There are also 1 to n number of decks created, so each player has their own deck. The players
preferred card is their player number. There are n*8 number of cards in each pack. The user
will be asked to input the location of the card pack. Once the card pack has been inserted 
the cards will be distributed in a round robin format to the players first, until each player
has 4 cards in their hands. Then the rest of the cards will be distributed to the deck in a 
similar round robin method. In order to win the game a player needs to have 4 of the same card
in their hand.

Players pick up cards that are not the same as their player number, and therefore will keep
cards which are the same as their player number in their hand. The players pick up the cards 
from the pull deck (the deck on the left) and discard cards to the put deck (deck on the right)

When a player has all cards in his hand equal to his player number he will inform the other
players that he has won. And then the other player threads will stop. The player will print
on the console when he has won the game.

Output files are created after the game has finished and there will be n output files depending
on the n number of players. The player output files will shower the end hands of all players.
Aswell as all the actions taken during the running of the program. The deck output file will
contain the decks at the end of the game. 
